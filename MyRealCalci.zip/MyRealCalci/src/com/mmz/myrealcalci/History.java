package com.mmz.myrealcalci;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class History extends Activity{

	TextView t;
	public void onCreate(Bundle b)
	{
		super.onCreate(b);
		setContentView(R.layout.history);
		t=(TextView)findViewById(R.id.prev);
		b=getIntent().getExtras();
		String s=b.getString("sb");
		t.setText(s);
	}
}
