package com.mmz.myrealcalci;





import com.mmz.myrealcalci.SimpleGestureFilter.SimpleGestureListener;
import com.navdrawer.SimpleSideDrawer;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;


public class MyCalci extends Activity implements SimpleGestureListener{
	ImageButton bone,btwo,bthree,bfour,bfive,bsix,bseven,boff,beight,bnine,bminus,bplus,bdivide,bmultiply,bequal,bdot,bobrace,bcbrace,bpow,bpie,bexp,bpow2,bpowx,bsqrt,bx,bsquare,bintegrate,bmatrix,bln,blog,bsin,bcos,btan,bclear,bdelete;
	TextView tv1,tv2,prev;
	TextView et;
	RadioGroup rg;
	String exp,exp1,res,radio;
	StringBuffer sb;
	Calci calci;
	Prob prob;
SimpleSideDrawer slide_me;
	private SimpleGestureFilter detector;
	int e=0,integrate,i,save,nu,npr,ncr,nr1,cx,x1;
	public double a,b,n,r,x;
	public void onCreate(Bundle b)
	{
		super.onCreate(b);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.firstlayout);
		calci=new Calci();
		prob=new Prob();
		detector = new SimpleGestureFilter(this,this);
		sb=new StringBuffer("");
		slide_me = new SimpleSideDrawer(this);
		slide_me.setRightBehindContentView(R.layout.history);
		bone=(ImageButton)findViewById(R.id.one);
		btwo=(ImageButton)findViewById(R.id.two);
		bthree=(ImageButton)findViewById(R.id.three);
		bfour=(ImageButton)findViewById(R.id.four);
		bfive=(ImageButton)findViewById(R.id.five);
		bsix=(ImageButton)findViewById(R.id.six);
		bseven=(ImageButton)findViewById(R.id.seven);
		beight=(ImageButton)findViewById(R.id.eight);
		bnine=(ImageButton)findViewById(R.id.nine);
		bminus=(ImageButton)findViewById(R.id.zero);
		bplus=(ImageButton)findViewById(R.id.plus);
		bdivide=(ImageButton)findViewById(R.id.divide);
		bmultiply=(ImageButton)findViewById(R.id.x);
		bequal=(ImageButton)findViewById(R.id.equal);
		bdot=(ImageButton)findViewById(R.id.dot);
		bobrace=(ImageButton)findViewById(R.id.obrace);
		bcbrace=(ImageButton)findViewById(R.id.cbrace);
		bpow=(ImageButton)findViewById(R.id.pow);
		bpie=(ImageButton)findViewById(R.id.pie);
		bexp=(ImageButton)findViewById(R.id.exp);
		bpow2=(ImageButton)findViewById(R.id.pow2);
		bpowx=(ImageButton)findViewById(R.id.powx);
		bsqrt=(ImageButton)findViewById(R.id.sqrt);
		bx=(ImageButton)findViewById(R.id.xvar);
		bsquare=(ImageButton)findViewById(R.id.xsq);
		bintegrate=(ImageButton)findViewById(R.id.integration);
		bmatrix=(ImageButton)findViewById(R.id.matrix);
		bln=(ImageButton)findViewById(R.id.ln);
		blog=(ImageButton)findViewById(R.id.log);
		bsin=(ImageButton)findViewById(R.id.sin);
		bcos=(ImageButton)findViewById(R.id.cos);
		btan=(ImageButton)findViewById(R.id.tan);
		bclear=(ImageButton)findViewById(R.id.clear);
		bdelete=(ImageButton)findViewById(R.id.delete);
		boff=(ImageButton)findViewById(R.id.off);
		tv1=(TextView)findViewById(R.id.tv1);
		tv2=(TextView)findViewById(R.id.tv);
		et=(TextView)findViewById(R.id.et);
		rg= (RadioGroup)findViewById(R.id.angle);
		prev=(TextView)findViewById(R.id.prev);
    }
	@Override
    public boolean dispatchTouchEvent(MotionEvent me){
    	// Call onTouchEvent of SimpleGestureFilter class
         this.detector.onTouchEvent(me);
       return super.dispatchTouchEvent(me);
    }
	@Override
	 public void onSwipe(int direction) {
	 
	  switch (direction) {
	  case SimpleGestureFilter.SWIPE_LEFT :  
		  prev.setText(sb.toString());
		  slide_me.toggleRightDrawer();
	        break;
	 
	  }
	 }
	 @Override
	 public void onDoubleTap() {
	    Toast.makeText(this, "Double Tap", Toast.LENGTH_SHORT).show();
	 }
	 
	public void clickOne(View v)
	{
		if(e==1)
			{
			et.setText("");
			tv2.setText("");
			tv1.setText("Enter");
			e=0;
			}
		exp=et.getText().toString();
		et.setText(exp+"1");
		nu=1;
	}
	public void clickTwo(View v)
	{
		if(e==1)
		{
		et.setText("");
		tv2.setText("");
		tv1.setText("Enter");
		e=0;
		}
		exp=et.getText().toString();
		et.setText(exp+"2");
		nu=1;
	}
	public void clickThree(View v)
	{
		if(e==1)
		{
		et.setText("");
		tv2.setText("");
		tv1.setText("Enter");
		e=0;
		}
		exp=et.getText().toString();
		et.setText(exp+"3");
		nu=1;
	}
	public void clickFour(View v)
	{
		if(e==1)
		{
		et.setText("");
		tv2.setText("");
		tv1.setText("Enter");
		e=0;
		}
		exp=et.getText().toString();
		et.setText(exp+"4");
		nu=1;
	}
	public void clickFive(View v)
	{
		if(e==1)
		{
		et.setText("");
		tv2.setText("");
		tv1.setText("Enter");
		e=0;
		}
		exp=et.getText().toString();
		et.setText(exp+"5");
		nu=1;
	}
	public void clickSix(View v)
	{
		if(e==1)
		{
		et.setText("");
		tv2.setText("");
		tv1.setText("Enter");
		e=0;
		}
		exp=et.getText().toString();
		et.setText(exp+"6");
		nu=1;
	}
	public void clickSeven(View v)
	{
		if(e==1)
		{
		et.setText("");
		tv2.setText("");
		tv1.setText("Enter");
		e=0;
		}
		exp=et.getText().toString();
		et.setText(exp+"7");
		nu=1;
	}
	public void clickEight(View v)
	{
		if(e==1)
		{
		et.setText("");
		tv2.setText("");
		tv1.setText("Enter");
		e=0;
		}
		exp=et.getText().toString();
		et.setText(exp+"8");
		nu=1;
	}
	public void clickNine(View v)
	{
		if(e==1)
		{
		et.setText("");
		tv2.setText("");
		tv1.setText("Enter");
		e=0;
		}
		exp=et.getText().toString();
		et.setText(exp+"9");
		nu=1;
	}
	public void clickZero(View v)
	{
		if(e==1)
		{
		et.setText("");
		tv2.setText("");
		tv1.setText("Enter");
		e=0;
		}
		exp=et.getText().toString();
		et.setText(exp+"0");
		nu=1;
	}
	public void clickObrace(View v)
	{
		if(e==1)
		{
		et.setText("");
		tv2.setText("");
		tv1.setText("Enter");
		e=0;
		}
		exp=et.getText().toString();
		et.setText(exp+"(");
		nu=0;
	}
	public void clickCbrace(View v)
	{
		if(e==1)
		{
		et.setText("");
		tv2.setText("");
		tv1.setText("Enter");
		e=0;
		return;
		}
			
		exp=et.getText().toString();
		et.setText(exp+")");
	}
	public void clickClear(View v)
	{
		et.setText("");
		tv1.setText("Enter");
		tv2.setText("calci");
		
		e=0;
		nu=0;
	}
	public void clickCos(View v)
	{
		if(e==1)
		{
		et.setText("");
		tv2.setText("");
		tv1.setText("Enter");
		e=0;
		}
		exp=et.getText().toString();
		et.setText(exp+"cos(");
		nu=0;
	}
	public void clickDelete(View v)
	{
		exp=et.getText().toString();
		String s;
    	if(exp.length()!=0)
    	{
    	s=exp.substring(0,exp.length()-1);
    	et.setText(s);
    	tv2.setText("");
    	
    	}
	}
	public void clickDivide(View v)
	{
		if(e==1)
		{
		et.setText(res);
		tv2.setText("");
		tv1.setText("Enter");
		e=0;
		}
		exp=et.getText().toString();
		et.setText(exp+"�");
		nu=0;
	}
	public void clickDot(View v)
	{
		if(e==1)
		{
		et.setText("");
		tv2.setText("");
		tv1.setText("Enter");
		e=0;
		}
		exp=et.getText().toString();
		et.setText(exp+".");
		nu=0;
	}
	
	public void clickExp(View v)
	{
		if(e==1)
		{
		et.setText("");
		tv2.setText("");
		tv1.setText("Enter");
		e=0;
		}
		exp=et.getText().toString();
		et.setText(exp+"e^(");
		nu=0;
	}
	public void clickIntegration(View v)
	{
		integrate=1;
		i=1;
		tv1.setText("Enter lower limit");
		et.setText("");
		nu=0;
	}
	public void clickLn(View v)
	{
		if(e==1)
		{
		et.setText("");
		tv2.setText("");
		tv1.setText("Enter");
		e=0;
		}
		exp=et.getText().toString();
		et.setText(exp+"ln(");
		nu=0;
	}
	public void clickLog(View v)
	{
		if(e==1)
		{
		et.setText("");
		tv2.setText("");
		tv1.setText("Enter");
		e=0;
		}
		exp=et.getText().toString();
		et.setText(exp+"Log(");
		nu=0;
	}
	public void clickMatrix(View v)
	{
		
	}
	public void clickMinus(View v)
	{
		if(e==1)
		{
		et.setText(res);
		tv2.setText("");
		tv1.setText("Enter");
		e=0;
		}
		exp=et.getText().toString();
		et.setText(exp+"-");
		nu=0;
	}
	public void clickPie(View v)
	{
		if(e==1)
		{
		et.setText("");
		tv2.setText("");
		tv1.setText("Enter");
		e=0;
		}
		exp=et.getText().toString();
		et.setText(exp+"pie");
		nu=0;
	}
	public void clickPlus(View v)
	{
		if(e==1)
	{
		et.setText(res);
		tv2.setText("");
		tv1.setText("Enter");
		e=0;
	}
		exp=et.getText().toString();
		et.setText(exp+"+");
		nu=0;
	}
	public void clickPow(View v)
	{
		if(e==1)
		{
			et.setText(res);
			tv2.setText("");
			tv1.setText("Enter");
			e=0;
		}
		exp=et.getText().toString();
		et.setText(exp+"^(");
		nu=0;
	}
	public void clickPow2(View v)
	{
		if(e==1)
		{
			et.setText("");
			tv2.setText("");
			tv1.setText("Enter");
			e=0;
		}
		exp=et.getText().toString();
		et.setText(exp+"10^(2)");
		nu=0;
	}
	public void clickPowx(View v)
	{
		if(e==1)
		{
			et.setText("");
			tv2.setText("");
			tv1.setText("Enter");
			e=0;
		}
		exp=et.getText().toString();
		et.setText(exp+"10^(");
		nu=0;
	}
	public void clickSin(View v)
	{
		if(e==1)
		{
			et.setText("");
			tv2.setText("");
			tv1.setText("Enter");
			e=0;
		}
		exp=et.getText().toString();
		et.setText(exp+"sin(");
		nu=0;
	}
	public void clickSqrt(View v)
	{
		if(e==1)
		{
			et.setText("");
			tv2.setText("");
			tv1.setText("Enter");
			e=0;
		}
		exp=et.getText().toString();
		et.setText(exp+"/(");
		nu=0;
	}
	public void clickTan(View v)
	{
		if(e==1)
		{
			et.setText("");
			tv2.setText("");
			tv1.setText("Enter");
			e=0;
		}
		exp=et.getText().toString();
		et.setText(exp+"tan(");
		nu=0;
	}
	public void clickX(View v)
	{
		if(e==1)
		{
			et.setText(res);
			tv2.setText("");
			tv1.setText("Enter");
			e=0;
		}
		exp=et.getText().toString();
		et.setText(exp+"*");
		nu=0;
	}
	public void clickXcube(View v)
	{
		if(e==1)
		{
			et.setText(res);
			tv2.setText("");
			tv1.setText("Enter");
			e=0;
		}
		exp=et.getText().toString();
		et.setText(exp+"^(3)");
		nu=0;
	}
	public void clickXpow(View v)
	{
		if(e==1)
		{
			et.setText(res);
			tv2.setText("");
			tv1.setText("Enter");
			e=0;
		}
		exp=et.getText().toString();
		et.setText(exp+"^(3)");
		nu=1;
	}
	public void clickXsq(View v)
	{
		if(e==1)
		{
			et.setText(res);
			tv2.setText("");
			tv1.setText("Enter");
			e=0;
		}
		exp=et.getText().toString();
		et.setText(exp+"^(2)");
		nu=1;
		
	}
	public void clickXvar(View v)
	{
		if(e==1)
		{
			et.setText("");
			tv2.setText("");
			tv1.setText("Enter");
			e=0;
		}
		exp=et.getText().toString();
		et.setText(exp+"x");
		cx=1;
		nu=0;
	}
	public void clickOff(View v)
	{
		if(save==0)
		{
		boff.setImageResource(R.drawable.on);
		save=1;
		}
		else
		{
			boff.setImageResource(R.drawable.off);
			save=0;	
		}
	}
	public void clickAns(View v)
	{
		if(e==1)
		{
			et.setText("");
			tv2.setText("");
			tv1.setText("Enter");
			e=0;
		}
		exp=et.getText().toString();
		if(res==null)
			et.setText(exp+"0");
		else
		et.setText(exp+res);
		nu=1;
	}
	
	public void clickSininv(View v)
	{
		if(e==1)
		{
			et.setText("");
			tv2.setText("");
			tv1.setText("Enter");
			e=0;
		}
		exp=et.getText().toString();
		et.setText(exp+"asin(");
		nu=0;

	}
	public void clickTaninv(View v)
	{
		if(e==1)
		{
			et.setText("");
			tv2.setText("");
			tv1.setText("Enter");
			e=0;
		}
		exp=et.getText().toString();
		et.setText(exp+"atan(");
		nu=0;

	}
	public void clickCosinv(View v)
	{
		if(e==1)
		{
			et.setText("");
			tv2.setText("");
			tv1.setText("Enter");
			e=0;
		}
		exp=et.getText().toString();
		et.setText(exp+"acos(");
		nu=0;
	}
	public void clickPer(View v)
	{
		if(e==1)
		{
			et.setText(res+"%");
			tv2.setText("");
			tv1.setText("Enter");
			e=0;
		}
		exp=et.getText().toString();
		if(nu==1)
			et.setText(exp+"%");
		else
			et.setText(exp);
		nu=0;
			
	}
	
	public void clickNpr(View v)
	{
		tv1.setText("Enter value of n");
		tv2.setText("");
		et.setText("");
		npr=1;
		nr1=1;
	}
	public void clickCpr(View v)
	{
		tv1.setText("Enter value of n");
		tv2.setText("");
		et.setText("");
		ncr=1;
		nr1=1;
	}
	public boolean onCreateOptionsMenu(Menu m)
	{
	MenuInflater mi=getMenuInflater();
	mi.inflate(R.menu.functions, m);
		return true;
	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		switch(item.getItemId())
		{
		case R.id.ex:
		finish();
		break;
		case R.id.date1:
			Intent i=new Intent(this,DateCalci1.class);
			startActivity(i);
			break;
		case R.id.history:
			Intent i1=new Intent(this,History.class);
			i1.putExtra("sb",sb.toString());
			startActivity(i1);
			break;
		case R.id.conversion:
			Intent i2=new Intent(this,DateCalculation.class);
			startActivity(i2);
			break;
		}
       return (true);
	}
	public void clickEqual(View v)
	{
		if(integrate==1)
		{
			if(i==1)
			{
			a=Double.parseDouble(et.getText().toString());
			tv1.setText("Enter upper limit");
			et.setText("");
			i++;
			}
			else if(i==2)
			{
				b=Double.parseDouble(et.getText().toString());
				tv1.setText("Enter Expression in x");
				et.setText("");
				i++;
			}
			else
			{
				e=1;
				 RadioButton rb= (RadioButton)findViewById(rg.getCheckedRadioButtonId());
				 radio=rb.getText().toString();
				exp=et.getText().toString();
				res=String.valueOf(calci.integrate(a,b,exp,radio));
				tv2.setText(res);
				et.setText("");
				tv1.setText("Ans");
				i=0;
				integrate=0;
			}
		}
		else if(npr==1||ncr==1)
		{
			if(nr1==1)
			{
			n=Double.parseDouble(et.getText().toString());
			tv1.setText("Enter value of r");
			tv2.setText("");
			nr1=0;
			}
			else
			{
				r=Double.parseDouble(et.getText().toString());
				if(npr==1)
				{
				res=String.valueOf(prob.npr(n,r));
				npr=0;
				tv2.setText(res);
				et.setText("");
				}
				else
				{
					res=String.valueOf(prob.ncr(n,r));
					ncr=0;
					tv2.setText(res);
					et.setText("");
				}
			}
		}
		else if(x1==1)
		{
			x=Double.parseDouble(et.getText().toString());
			calci.getx(x);
			res=String.valueOf(calci.infixFun(exp1,radio));
			tv2.setText(res);
			tv1.setText("Result");
			if(save==1)
				sb.append("->"+exp1+"="+res+" "+"x="+x+"\n");
			x1=0;
		}
		else
		{
		e=1;
		 RadioButton rb= (RadioButton)findViewById(rg.getCheckedRadioButtonId());
		 radio=rb.getText().toString();
		exp=et.getText().toString();
		if(cx==1)
		{
		  tv1.setText("Enter value of x");
		  tv2.setText("");
		  et.setText("");
		  x1=1;
		  cx=0;
		  exp1=exp;
		}
		else{
			res=String.valueOf(calci.infixFun(exp,radio));
			tv2.setText(res);
			tv1.setText("Result");
			if(save==1)
			sb.append("->"+exp+"="+res+"\n");
			et.setText("");
		}
	}
		nu=0;
	}
	
}
