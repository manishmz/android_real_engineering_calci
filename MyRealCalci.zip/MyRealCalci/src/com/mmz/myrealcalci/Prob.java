package com.mmz.myrealcalci;

public class Prob {
	public double npr(double n,double r)
	{
		double ans=0;
		if(n>r)
		ans=fact(n)/fact(n-r);
		return ans;
	}
	public double ncr(double n,double r)
	{
		double ans=0;
		if(n>r)
		ans=fact(n)/(fact(n-r)*fact(r));
		return ans;
	}
	public double fact(double f)
	{
		double i,sum=1;
		for(i=f;i>1;i--)
		{
			sum=sum*f;
		}
		return f;
	}

}
