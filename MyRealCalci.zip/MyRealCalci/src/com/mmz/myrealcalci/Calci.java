package com.mmz.myrealcalci;

public class Calci {

	StringBuffer infix;
	StringBuffer s=new StringBuffer("#");
	StringBuffer polish=new StringBuffer();
	int top,t=-1,opt;
	Double integer[]=new Double[20];
	double res,val;
	void getx(double x)
	{
		val=x;
	}
	double infixFun(String inf,String radio)
	{
			int  i,j=0,v,b,so=0,k,c=0,a=0,po,l=0,L=0,si=0,co=0,ta=0,q=0,e=1,ex=0,brack=0,tinv=0,sinv=0,cinv=0;
		double op1,op2,sum=0,ch;
		char symb,temp;
		infix=new StringBuffer(inf);
		MyCalci mycalci=new MyCalci();
		infix.append("$");
	
	//converting infix expression into postfix
			for(i=0;i<infix.length()-1;i++)
			{
			 symb=infix.charAt(i);
			 if(symb=='^' && s.charAt(top)=='^')
			 {
			push(symb);
			}
			else if(symb=='x'||symb=='X')
			{
			push1(val);
			}
			else if(symb=='%')
			{
			push1(0.01);
			}
			else if(symb=='p')
			{
				push1(Math.PI);
				i=i+2;
			}
			else if(symb=='/'||symb=='e')
			{
			a=1;
			polish.append(symb);
			}
			else if(symb=='a')
			{
			a=1;
			if(infix.charAt(i+1)=='s')
			polish.append('i');
			else if(infix.charAt(i+1)=='c')
				polish.append('o');
			else if(infix.charAt(i+1)=='t')
				polish.append('a');
			i=i+3;
			}
			else if(symb=='l'||symb=='e')
			{
			a=1;
			polish.append(symb);
			i=i+1;
			}
			else if(symb=='L'||symb=='c'||symb=='s'||symb=='t')
			{
			a=1;
			polish.append(symb);
			i=i+2;
	        }
		   
		    else if((symb>=48&&symb<=57)||symb==46)
		       {
			if(infix.charAt(i+1)=='$'||(infix.charAt(i+1)<48||infix.charAt(i+1)>57)&&infix.charAt(i+1)!=46)
			{
			v=i;
			c=0;
			po=0;
			while(v>=0&&(infix.charAt(v)>=48&&infix.charAt(v)<=57)||infix.charAt(v)==46)
			{
				if(infix.charAt(v)==46)
				c=1;
			if(c==0)
				po--;
				v--;
				if(v==-1)
				break;
			}
			v=i;
			b=0;
			sum=0;
			while(v>=0&&(infix.charAt(v)>=48&&infix.charAt(v)<=57)||infix.charAt(v)==46)
			{
				if(infix.charAt(v)==46)
			v--;
				else if(c==1)
				{	
				ch=infix.charAt(v)-'0';
				for(k=po;k<0;k++)
				{   
					ch=ch/10.0f;	
				}
				for(k=0;k<po;k++)
				{
					ch=ch*10;
				}
				sum=sum+ch;
				po++;
				v--;
					
				}
				else
			  {	ch=infix.charAt(v)-'0';
				for(k=0;k<b;k++)
				{
					ch=ch*10;	
				}
				sum=sum+ch;
				b++;
				v--;
			}
			if(v==-1)
			break;
			}
			}
		push1(sum);
		}
		else if(symb=='(')
		{
		push(symb);
		}
		else if(symb==')')
		{
		while(s.charAt(top)!='(')
		{temp=pop();
		polish.append(temp);
		push1(12345);
		}
		pop();
		if(a==1)
		{
			push1(54321);
			polish.append("?");
		}
		}
		else
		{
		while(prec(symb)<=prec(s.charAt(top)))
		{
		temp=pop();
		polish.append(temp);
		push1(12345);
		}
		push(symb);
		}
		}
		while(s.charAt(top)!='#')
		{
		temp=pop();
		polish.append(temp);
		push1(12345);
		}
	
		//evaluating postfix expression
	
		for(i=0;i<polish.length();i++)
		{  so=0;	
			symb=polish.charAt(i);
			if(symb=='/')
			{
			q=1;
			i++;
			}
			if(symb>='a'&&symb<='z')
			{
				if(symb=='a')
					tinv=1;
				if(symb=='i')
					sinv=1;
				if(symb=='o')
					cinv=1;
			if(symb=='l')
			l=1;
			if(symb=='L')
				L=1;
			 if(symb=='c')
			co=1;
			 if(symb=='s')
			si=1;
			 if(symb=='t')
			ta=1;
		        if(symb=='e')
			ex=1;
		        i++;
		        }
				
				if(i!=polish.length())
			symb=polish.charAt(i);
			if(symb=='?')
			{
		        while(integer[so]!=54321)
			so++;
			if(l==1)
			{ 
		         res=Math.log(integer[so-1]);
			l=0;
			}
			if(L==1)
			{ 
		         res=Math.log10(integer[so-1]);
			L=0;
			}
			 if(co==1)
			{
				 if(radio.equals("rad"))
		         res=Math.cos(integer[so-1]);
				 else
					 res=Math.cos(Math.toRadians(integer[so-1]));
			co=0;
			}
			 if(si==1)
			{
				 if(radio.equals("rad"))
				res=Math.sin(integer[so-1]);
				 else
					 res=Math.sin(Math.toRadians(integer[so-1])); 
			si=0;
			}
			 if(ta==1)
			{
				 if(radio.equals("rad"))
		         res=Math.tan(integer[so-1]);
				 else
					 res=Math.tan(Math.toRadians(integer[so-1])); 
			ta=0;}
			if(q==1)
			{
		        res=Math.sqrt(integer[so-1]);
			q=0;
		         }
		    if(ex==1)
			{
		        res=Math.exp(integer[so-1]);
			ex=0;
		    }
		    if(sinv==1)
			{
				 if(radio.equals("rad"))
				res=Math.asin(integer[so-1]);
				 else
						res=Math.toDegrees(Math.asin(integer[so-1]));

			sinv=0;
			}
		    if(cinv==1)
			{
				 if(radio.equals("rad"))
				res=Math.acos(integer[so-1]);
				 else
						res=Math.toDegrees(Math.acos(integer[so-1]));

			cinv=0;
			}
		    if(tinv==1)
			{
				 if(radio.equals("rad"))
				res=Math.atan(integer[so-1]);
				 else
						res=Math.toDegrees(Math.atan(integer[so-1]));

			tinv=0;
			}
		    
				integer[so]=res;
				for(j=so-1;j<=t-1;j++)
				{
					integer[j]=integer[j+1];
				}
				t=t-1;
			}
			else
			{
			while(integer[so]!=12345)
			{
			so++;	
			}	
			op2=integer[so-1];
			op1=integer[so-2];
			switch(symb)
					{
						case '+':
							res=op1+op2;
							break;
						case '-':
							res=op1-op2;
					
							break;
						case '�':
							res=op1/op2;
							break;
						case '*':
							res=op1*op2;
							break;
						case '^':
							res=Math.pow(op1,op2);
							break;	
					}
			
				integer[so]=res;
				for(j=so-2;j<t-1;j++)
				{
					integer[j]=integer[j+2];
				}
				t=t-2;
		}
		}
		res=pop1();
		polish.delete(0,polish.length());
		return res;
  }
	
	
	
		//////////////////////////////////////
    void push(char ch)
	{
		if(top==9)
		{
		return;
		}
		top++;
		s.append(ch);
	}
	char pop()
		{
		char t;
		t=s.charAt(top);
		s.deleteCharAt(top);
		top--;
		return t;
	}
	public int prec(char ch)
		{
		switch(ch)
		{
			case '#':
			return 1;
			case '+':
			case '-':
			return 2;
			case '*':
			case '�':
			return 3;
			case '^':
			return 4;
			case '(':
			return 0;
		}
		return 0;
	}

	public void push1(double x)
	{
		if(t==19)
		{
			return;
		}
		t++;
		integer[t]=x;

	}
	
	public double pop1()
	{
		double r;
		if (t==-1)
			{
		
				return 0;
			}
		r=integer[t];
		t--;
		return r;

	}
	double integrate(double a,double b,String inf,String radio)
	{
		 double h,y,f;
		 int j;
	     h=(b-a)/Math.pow(2,10);
		 f=0;
		 opt=5;
		 for(j=1;j<=Math.pow(2,10);j++)
		 {
			val=a+(j-0.5)*h;
			f=f+infixFun(inf,radio);
		 }
		 y=h*f;
	     return y;
	}
}
