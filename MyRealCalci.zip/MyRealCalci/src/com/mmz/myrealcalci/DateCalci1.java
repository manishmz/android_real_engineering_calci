package com.mmz.myrealcalci;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class DateCalci1 extends Activity implements OnItemSelectedListener{
	
	Spinner spin;
	EditText e1,e2;
	TextView t1,t2;
	public void onCreate(Bundle b)
	{
	super.onCreate(b);
	requestWindowFeature(Window.FEATURE_NO_TITLE);
	setContentView(R.layout.datecalculation);
	String[] options={"Difference betwen two days","Add or Subtract days"};
	spin=(Spinner)findViewById(R.id.spinner1);
	ArrayAdapter aa=new ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,options);
	aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
	spin.setAdapter(aa);
	spin.setOnItemSelectedListener(this);
	e1=(EditText)findViewById(R.id.from);
	e2=(EditText)findViewById(R.id.to);
	t1=(TextView)findViewById(R.id.tv1);
	t2=(TextView)findViewById(R.id.tv2);
	}
	@Override
	public void onItemSelected(AdapterView<?> parent,View v,int pos,long id)
	{
		String selectedItem = parent.getItemAtPosition(pos).toString();
        if(selectedItem=="Add or Subtract days")
        {
        	Toast.makeText(this, "add or subtract",Toast.LENGTH_LONG).show();
        	//Intent i=new Intent(this,DateCalculation2.class);
        	//startActivity(i);
        }
	}
	public void onNothingSelected(AdapterView<?> parent)
	{
		
	}
	public void clickCalculate(View v)
	 {
		int date1,date2,month1,month2,year1,year2;
		 String from=e1.getText().toString();
		 String to=e2.getText().toString();
		  date1=Integer.parseInt(from.substring(0,2));
		 month1=Integer.parseInt(from.substring(3,5));
		  year1=Integer.parseInt(from.substring(6,10));
		 date2=Integer.parseInt(to.substring(0,2));
		  month2=Integer.parseInt(to.substring(3,5));
		  year2=Integer.parseInt(to.substring(6,10));
		 int resdate=date2-date1;
		 int resmonth=month2-month1;
		 int resyear=year2-year1;
		 t1.setText(String.valueOf(resyear)+" year,"+String.valueOf(resmonth)+" month,"+String.valueOf(resdate)+" days");
	 }

}
